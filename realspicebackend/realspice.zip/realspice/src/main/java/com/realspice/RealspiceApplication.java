package com.realspice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RealspiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RealspiceApplication.class, args);
	}

}
