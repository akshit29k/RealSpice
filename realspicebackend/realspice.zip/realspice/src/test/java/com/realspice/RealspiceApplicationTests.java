package com.realspice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RealspiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
